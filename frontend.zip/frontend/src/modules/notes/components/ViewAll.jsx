import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { apiClient } from '../../../shared/services/api-client';
import {useDispatch, useSelector} from 'react-redux';
import noteSlice, { getNotes } from '../redux/note-slice';
export const ViewAll = () => {
  const dispatch = useDispatch(); // Push
  const selector = useSelector(state=>state);
  console.log('####### Selector is ', selector);
  //const [notes, setNotes] = useState([]);
  // const getNotes = async ()=>{
  //   const data =await apiClient.get(process.env.REACT_APP_VIEW_URL);
  //   console.log('All Notes Data is ', data);
  //   setNotes(data.records);
  // }
  useEffect(()=>{
    dispatch(getNotes());
    //getNotes();
    // [] - Mount
    // no [] - update
    // [] and function return - unmount
  },[]); // Life Cycle Hook
    // const params = useParams();
    // console.log('Params are ', params);
  return (
    <>
    <h1>View All</h1>
    {selector.isLoading && <p>Loading...</p>}
    {!selector.isLoading && selector.notes && selector.notes.records && selector.notes.records.length>0 && selector.notes.records.map(note=>{
      return <p>{note.title} {note.desc}</p>
    }) }
    </>
    // <div>ViewAll {params?.screentype}</div>
  )
}

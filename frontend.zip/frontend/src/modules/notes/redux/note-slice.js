import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { apiClient } from "../../../shared/services/api-client";

// Async Action 
export const getNotes = createAsyncThunk('/get-notes',async ()=>{
    
    const data =await apiClient.get(process.env.REACT_APP_VIEW_URL);
    console.log('All Notes Data is ', data);
    return data;
})

const noteSlice = createSlice({
    name:'noteSlice',
    initialState:{"notes":[], isLoading:false, err: null},
    reducers:{
        // Sync Logic
        addNote(state, action){
            state.notes.push(action.payload);
        },
        updateNote(state, action){
            
        },
        searchNote(state, action){

        }
    },
    extraReducers:(builder)=>{
        builder
        .addCase(getNotes.pending,(state, action)=>{
            state.isLoading = true;
        })
        .addCase(getNotes.fulfilled,(state, action)=>{
            state.isLoading = false;
            state.notes = action.payload;
        })
        .addCase(getNotes.rejected, (state, action)=>{
            state.isLoading = false;
            state.err = action.payload;
        })
    }
});
export default noteSlice.reducer;
import React from 'react'
import { Route, Routes } from 'react-router-dom'
import { AddNote } from '../../modules/notes/components/AddNote'
import { ViewAll } from '../../modules/notes/components/ViewAll'
import { UpdateNote } from '../../modules/notes/components/UpdateNote'
import { SearchNote } from '../../modules/notes/components/SearchNote'

export const Main = () => {
  return (
    <div>
        <Routes>
            <Route path="/" element={<ViewAll/>}/>
            <Route path='add-note' element={<AddNote/>} />
            <Route path='view-all/:screentype' element={<ViewAll/>} />
            <Route path='update-note' element={<UpdateNote/>} />
            <Route path='search-note' element={<SearchNote/>} />
        </Routes>
    </div>
  )
}

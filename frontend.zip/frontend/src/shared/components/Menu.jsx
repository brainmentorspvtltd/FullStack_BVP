import React from 'react'
import {NavLink} from 'react-router-dom';
export const Menu = () => {
  return (
    <div>
        <NavLink to="/" >Home</NavLink>
        <br/>
        <NavLink to="/add-note" >Add Note</NavLink>
        <br/>
        <NavLink to="/view-all/view" >View All</NavLink>
        <br/>
        <NavLink to="/view-all/update" >Update Note</NavLink>
        <br/>
        <NavLink to="/view-all/search" >Search Note</NavLink>
        <br/>
        <NavLink to="/view-all/delete" >Delete Note</NavLink>
        <br/>
    </div>
  )
}

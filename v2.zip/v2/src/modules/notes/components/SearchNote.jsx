import React from 'react'

export const SearchNote = () => {
  return (
    <div>SearchNote</div>
  )
}

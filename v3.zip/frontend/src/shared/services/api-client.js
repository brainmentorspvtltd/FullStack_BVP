// API CLient (Call WEBAPIs)
import axios from 'axios';
export const apiClient = {
   async get(URL){
    try{
        const response =await axios.get(URL);
        return response.data;
    }
    catch(err){
        throw err;
    }
    }
}
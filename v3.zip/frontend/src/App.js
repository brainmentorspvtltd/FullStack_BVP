import logo from './logo.svg';
import './App.css';
import {DashBoard} from './modules/notes/pages/DashBoard';
function App() {
  return (
    <DashBoard/>
  );
}

export default App;

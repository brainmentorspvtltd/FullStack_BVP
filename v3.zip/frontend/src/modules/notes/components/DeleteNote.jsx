import React from 'react'

export const DeleteNote = () => {
  return (
    <div>DeleteNote</div>
  )
}

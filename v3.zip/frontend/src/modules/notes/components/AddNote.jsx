import React from 'react'

export const AddNote = () => {
  return (
    <div>AddNote</div>
  )
}

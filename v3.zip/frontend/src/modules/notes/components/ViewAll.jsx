import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { apiClient } from '../../../shared/services/api-client';

export const ViewAll = () => {
  const [notes, setNotes] = useState([]);
  const getNotes = async ()=>{
    const data =await apiClient.get(process.env.REACT_APP_VIEW_URL);
    console.log('All Notes Data is ', data);
    setNotes(data.records);
  }
  useEffect(()=>{
    getNotes();
    // [] - Mount
    // no [] - update
    // [] and function return - unmount
  },[]); // Life Cycle Hook
    // const params = useParams();
    // console.log('Params are ', params);
  return (
    <>
    <h1>View All</h1>
    {notes.length===0 && <p>No Notes</p>}
    {notes.length>0 && notes.map(note=>{
      return (<p>{note.title} {note.desc}</p>)
    })}
    </>
    // <div>ViewAll {params?.screentype}</div>
  )
}

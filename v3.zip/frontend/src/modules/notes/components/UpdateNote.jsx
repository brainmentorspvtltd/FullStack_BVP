import React from 'react'

export const UpdateNote = () => {
  return (
    <div>UpdateNote</div>
  )
}

import mongoose from 'mongoose';
const URL = "mongodb+srv://amit:a123456@note-cluster.ez50ord.mongodb.net/notedb?retryWrites=true&w=majority";
const promise = mongoose.connect(URL);
promise.then(data=>{
    console.log('DB Connected...');
}).catch(err=>{
    console.log('Error is ',err);
})
export default mongoose;
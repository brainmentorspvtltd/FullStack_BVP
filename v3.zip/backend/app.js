import express from 'express';
import { userRoute } from './modules/user/routes/user-routes.js';
import { noteRouter } from './modules/note/routes/note-routes.js';
import cors from 'cors';
const app = express(); 
app.use(cors());
app.use(express.json()); // app.use(middleware) , middleware is just a function(request, response, next)
app.use('/', userRoute); 
app.use('/',noteRouter);
const server = app.listen(1234,(err)=>{
    if(err){
        console.log('Server Crash ', err);
    }
    else{
        console.log('Server Up and Running ', 
        server.address().port);
    }
})
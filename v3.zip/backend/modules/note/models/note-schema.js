import { SchemaTypes } from 'mongoose';
import mongoose from '../../../shared/db/connection.js';
const Schema = mongoose.Schema;
const noteSchema =new Schema({
    'title':{type:SchemaTypes.String, required:true, unique:true},
    'desc':{type:SchemaTypes.String},
    'completionDate':{type:SchemaTypes.Date, default:new Date()},
    'importance':{type:SchemaTypes.String, required:true},
    'status':{type:SchemaTypes.String, default:'A'}

});
export const NoteModel = mongoose.model('notes', noteSchema);
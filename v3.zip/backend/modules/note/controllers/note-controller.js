import { NoteModel } from "../models/note-schema.js";

export const noteController = {
    async addNote(request, response){
        const noteObject = request.body;
        try{
        const doc = await NoteModel.create(noteObject);
        console.log('Note Object Rec ', noteObject);
        response.json({message:'Note Added...', record : doc});
        }
        catch(err){
            console.log('Note Add Error ', err);
            response.json({message:'Something Went Wrong...'});
        }
    },
    async viewAllNotes(request, response){
        try{
        const docs = await NoteModel.find({}).select("title desc -_id").exec();
        response.json({message:'View All Note', records:docs});
        }
        catch(err){
            console.log('Note read error ', err);
            response.json({message:'Something Went Wrong...'});
        }
    }
}
import express from 'express';
import { noteController } from '../controllers/note-controller.js';
export const noteRouter = express.Router();
noteRouter.post('/add-note', noteController.addNote); // Write
noteRouter.get('/view-note', noteController.viewAllNotes); // Read
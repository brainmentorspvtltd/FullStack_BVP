export const Message = ({value,classname,countValue})=>{
    const myClass = `alert alert-${classname} text-center`;
    return <h1 className ={myClass} >{value} {countValue}</h1>
}
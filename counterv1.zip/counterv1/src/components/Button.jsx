export const Button = (props)=>{
    const classname = `btn btn-${props.classname}`;
    return <button className ={classname} >{props.value}</button>
}
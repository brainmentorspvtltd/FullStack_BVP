import React from 'react'
import { Message } from '../components/Message'
import { Button } from '../components/Button'

export const CounterPage = () => {
    let count = 0;
  return (
    <div className="container">
        <Message classname="info" value = "Counter App"/>
        <Message classname="success" value = "Count Value is " countValue ={count}/>
        <Button classname="success" value="+"/> &nbsp;&nbsp;
        <Button classname="danger" value="-"/>
    </div> 
  )
}

// Glue B/w View and Model
// Controller UI I/O
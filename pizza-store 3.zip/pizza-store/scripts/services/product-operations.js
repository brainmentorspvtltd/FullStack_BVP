// Products CRUD Operation
// C - Create  , R  - Read, U - Update , D - Delete
import doNetworkCall from './api-client.js';
export default async function readAllProducts(){
    try{
        const obj = await doNetworkCall();
    }
    catch(err){
        throw err;
    }
}
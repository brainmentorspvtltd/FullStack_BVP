export const userController = {
    register(request , response){
        const body = request.body; // Post Data
        console.log('Body is ', body);
        response.json({message:'Register'});
    },
    login(request , response){
        response.json({message:'Login'});
    },
    changePassword(request , response){
        response.json({message:'Change Pwd'});
    },
    profile(request , response){
        const userName = request.params.username; // Get (Path param)
        response.json({message:'Profile '+userName});
    },
    removeAccount(request , response){
        response.json({message:'Remove Account'});
    }
}
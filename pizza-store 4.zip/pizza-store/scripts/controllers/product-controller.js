// Glue B/w View and Model
// Controller UI I/O

import readAllProducts from "../services/product-operations.js";

async function showProducts(){
    const products = await readAllProducts();
    console.log('Controller rec ', products);
}
showProducts();
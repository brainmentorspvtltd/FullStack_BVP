import logo from './logo.svg';
import './App.css';
import { CounterPage } from './pages/CounterPage';

function App() {
  console.log('App Re-Render');
  return (
    <CounterPage/>
  );
}

export default App;

export const Button = (props)=>{
    console.log('BUtton Re-Render');
    const classname = `btn btn-${props.classname}`;

    const clicked = ()=>{
        props.fn(props.value); // Child call parent logic function
        console.log('Clicked Happen....', props.value);
    }
    return <button onClick={clicked} className ={classname} >{props.value}</button>
}
import React from 'react'
import { Message } from '../components/Message'
import { Button } from '../components/Button'
import { useState } from 'react';

export const CounterPage = () => {
  console.log('Counter Page Fn CAlls');
    //let count = 0;
    const [count, setCount] = useState(0); // Now u can do state handling
    // Hook
  const logic = (buttonValue)=>{
    if(buttonValue === '+'){
      setCount(count + 1); // Re-rendering (Async)
      console.log(count);
      //count++;
    }
    else {
      setCount(count-1);
      //count--;
    }
    
    console.log('Count is ', count);
  }  
  return (
    <div className="container">
        <Message classname="info" value = "Counter App"/>
        <Message classname="success" value = "Count Value is " countValue ={count}/>
        <Button fn = {logic} classname="success" value="+"/> &nbsp;&nbsp;
        <Button fn = {logic} classname="danger" value="-"/>
    </div> 
  )
}

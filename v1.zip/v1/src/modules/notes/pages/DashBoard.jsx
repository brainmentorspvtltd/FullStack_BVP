import {Header} from '../../../shared/components/Header';
export const DashBoard = ()=>{
    return (<Header/>)
}
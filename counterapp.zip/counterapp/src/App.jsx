

/*

Component - it is a small view
contains JSX(JavaScript and XML)
JSX - Object Oriented 
JSX - 99% HTML Like Syntax
*/
import React from 'react';
import { Greet } from './components/Greet';
const App = ()=>{
  const name = 'Amit Srivastava';
 // return React.createElement('div', null,React.createElement('h1',{style:{color:'red', backgroundColor:'green'}},'Hello ReactJS'),React.createElement('h1',null,'Hi ReactJS'));
  const student = {id:1001, name:'Ram', age:21};
  
  return (
  <div>
    {name.startsWith("A")?<p>Welcome {name}</p>:<p>Hi {name}</p>}
    <h3>Student Info {student.id} {student.name} {student.age}</h3>
  <h1>Welcome {name}</h1>
  <h2>Hi React JS...{Date.now()}</h2>
  <Greet myname= {name} />
  </div>
  )
}
export default App;
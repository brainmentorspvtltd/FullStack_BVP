/*
Bridge file b/w App Component and index.html
From App Component we get JSX (VDOM) and Give it 
to ReactDOM , to convert VDOM into DOM.
*/
import ReactDOM from 'react-dom/client';
import App from './App';
// DOM
const div = document.querySelector('#root');
const root = ReactDOM.createRoot(div);
root.render(<App/>);
// Component call in JSX Style